package sample;

import java.io.Serializable;
import java.util.ArrayList;

public class Tutorial extends Content implements Serializable {
    private String needings;

    public Tutorial() {
    }


    public Tutorial(Long id, String category, String title, String description, String needings) {
        super(id, category, title, description);
        this.needings = needings;
    }

    public Tutorial(Long id, String category, String title, String description, double rating, int ratedUser_count, String needings) {
        super(id, category, title, description, rating, ratedUser_count);
        this.needings = needings;
    }

    public String getNeedings() {
        return needings;
    }

    public void setNeedings(String needings) {
        this.needings = needings;
    }

    public String details() {
        return getTitle() + "; Category: " + getCategory();
    }

    @Override
    public String toString() {
        return getTitle() + '\n' +
                "Category: " + getCategory() + ";\n" +
                "Rating: " + getRating() + ";\n" +
                "What you need" + needings + ";\n" +
                getDescription() + '\n';
    }
}
