package sample;

import java.io.Serializable;

public class Request implements Serializable {
    private String code;
    private User user;
    private Comment comment;
    private Good good;
    private Tutorial tutorial;
    private Follower follower;
    private Long id;

    public Request() {
    }

    public Request(String code) {
        this.code = code;
    }

    public Request(String code, Long id) {
        this.code = code;
        this.id = id;
    }

    public Request(String code, User user) {
        this.code = code;
        this.user = user;
    }

    public Request(String code, Comment comment) {
        this.code = code;
        this.comment = comment;
    }

    public Request(String code, Good good) {
        this.code = code;
        this.good = good;
    }

    public Request(String code, Tutorial tutorial) {
        this.code = code;
        this.tutorial = tutorial;
    }

    public Request(String code, Follower follower) {
        this.code = code;
        this.follower = follower;
    }

    public Request(String code, Long id, Tutorial tutorial) {
        this.code = code;
        this.id = id;
        this.tutorial = tutorial;
    }

    public Request(String code, Long id, Good good) {
        this.code = code;
        this.id = id;
        this.good = good;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Comment getComment() {
        return comment;
    }

    public void setComment(Comment comment) {
        this.comment = comment;
    }

    public Good getGood() {
        return good;
    }

    public void setGood(Good good) {
        this.good = good;
    }

    public Tutorial getTutorial() {
        return tutorial;
    }

    public void setTutorial(Tutorial tutorial) {
        this.tutorial = tutorial;
    }

    public Follower getFollower() {
        return follower;
    }

    public void setFollower(Follower follower) {
        this.follower = follower;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "Request{" +
                "code='" + code + '\'' +
                ", user=" + user +
                ", comment=" + comment +
                ", good=" + good +
                ", tutorial=" + tutorial +
                '}';
    }
}
