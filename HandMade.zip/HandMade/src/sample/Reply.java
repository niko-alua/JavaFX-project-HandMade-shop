package sample;

import java.io.Serializable;
import java.util.ArrayList;

public class Reply implements Serializable {
    private String code;
    private ArrayList<User> users = null;
    private ArrayList<Comment> comments = null;
    private ArrayList<Good> goods = null;
    private ArrayList<Tutorial> tutorials = null;
    private ArrayList<Follower> followers = null;

    public Reply() {
        users = new ArrayList<>();
        comments = new ArrayList<>();
        goods = new ArrayList<>();
        tutorials = new ArrayList<>();
        followers = new ArrayList<>();
    }

    public Reply(String code) {
        this.code = code;
    }

    public void addUser(User user){
        users.add(user);
    }

    public void addСomment(Comment comment){
        comments.add(comment);
    }

    public void addGood(Good good){
        goods.add(good);
    }

    public void addTutorial(Tutorial tutorial){
        tutorials.add(tutorial);
    }

    public void addFollower(Follower follower) {
        followers.add(follower);
    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public ArrayList<Good> getGoods() {
        return goods;
    }

    public ArrayList<Tutorial> getTutorials() {
        return tutorials;
    }

    public ArrayList<Follower> getFollowers() {
        return followers;
    }

    public void setFollowers(ArrayList<Follower> followers) {
        this.followers = followers;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
