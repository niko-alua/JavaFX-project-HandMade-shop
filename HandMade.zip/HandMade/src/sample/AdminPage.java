package sample;

public class AdminPage {
}
