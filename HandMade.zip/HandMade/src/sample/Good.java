package sample;

import java.io.Serializable;
import java.util.ArrayList;

public class Good extends Content implements Serializable {
    private String material;
    private String colour;
    private double price;
    private int count;
    private int sold;

    public Good(){}

    public Good(Long id, String category, String title, String description, String material, String colour, double price, int count) {
        super(id, category, title, description);
        this.material = material;
        this.colour = colour;
        this.price = price;
        this.count = count;
    }

    public Good(Long id, String category, String title, String description, double rating, int ratedUser_count, String material, String colour, double price, int count, int sold) {
        super(id, category, title, description, rating, ratedUser_count);
        this.material = material;
        this.colour = colour;
        this.price = price;
        this.count = count;
        this.sold = sold;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getColour() {
        return colour;
    }

    public void setColour(String colour) {
        this.colour = colour;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getSold() {
        return sold;
    }

    public void setSold(int sold) {
        this.sold = sold;
    }

    public String details() {
        return getTitle() + "; Category: " + getCategory() + "; Price: " + price;
    }

    @Override
    public String toString() {
        return "Good{" +
                "material='" + material + '\'' +
                ", colour='" + colour + '\'' +
                ", price=" + price +
                ", count=" + count +
                ", sold=" + sold +
                '}';
    }
}
