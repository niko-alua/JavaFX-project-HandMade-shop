package sample;

import com.sun.xml.internal.ws.api.model.wsdl.WSDLOutput;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
import java.util.SimpleTimeZone;

public class ClientApp {
    public static void main(String[] args) {
        /*try {
            Socket socket = new Socket("127.0.0.1", 1999);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            Scanner in = new Scanner(System.in);
            while (true) {
                System.out.println("Choose:\n" +
                        "1. to register;\n" +
                        "2. to login;\n" +
                        "0. break;\n");

                int choice = in.nextInt();

                if (choice == 1) {
                    System.out.println("Please enter");
                    System.out.print("Username: ");
                    String username = in.next();
                    System.out.print("Password: ");
                    String password = in.next();
                    System.out.print("Confirm the password: ");
                    String passwordCheck = in.next();
                    if (!passwordCheck.equals(password)) {
                        System.out.println("\nPasswords do not match");
                    } else {
                        User user = new User(null, username, password, false, false);
                        Request req = new Request("ADD_USER", user);
                        oos.writeObject(req);

                        Reply rep = (Reply)ois.readObject();
                        System.out.println(rep.getCode());
                    }
                }

                if (choice == 2) {
                    System.out.println("Please enter");
                    System.out.print("Username: ");
                    String username = in.next();
                    System.out.print("Password: ");
                    String password = in.next();
                    Request req = new Request("VIEW_USERS");
                    oos.writeObject(req);

                    Reply rep  = (Reply)ois.readObject();

                    ArrayList<User> users = rep.getUsers();

                    for(User user : users){
                        if (user.getUsername().equals(username) && user.getPassword().equals(password)){
                            req = new Request("SET_AUTHENTICATED_USER", user.getUser_id());
                            oos.writeObject(req);
                            if(user.isAdmin()){
                                System.out.println("Choose:\n" +
                                        "1.Tutorials;\n" +
                                        "2.Goods;\n" +
                                        "0. break;\n");

                                int choice_2 = in.nextInt();

                                if(choice_2 == 1) {
                                    System.out.println("Choose:\n" +
                                            "1.Edit;\n" +
                                            "2.Add;\n" +
                                            "3.Delete;\n" +
                                            "0.Break;\n");

                                    int choice_3 = in.nextInt();
                                    if(choice_3 == 1) {
                                        req = new Request("VIEW_TUTORIALS");
                                        oos.writeObject(req);

                                        rep  = (Reply)ois.readObject();

                                        ArrayList<Tutorial> tutorials = rep.getTutorials();

                                        for (Tutorial tutorial: tutorials) {
                                            System.out.print(tutorial.getId());
                                            System.out.print(' ');
                                            System.out.println(tutorial);
                                        }

                                        System.out.println("Which tutorial you want to edit?");
                                        Long tutorNum = in.nextLong();

                                        for (Tutorial tutorial: tutorials){
                                            if(tutorNum.equals(tutorial.getId())){
                                                System.out.println("Choose:\n" +
                                                        "1.Category;\n" +
                                                        "2.Title;\n" +
                                                        "3.Description;\n" +
                                                        "4.Needings;\n" +
                                                        "0.Break;\n");
                                                int choice_4 = in.nextInt();
                                                if(choice_4 == 1) {
                                                    System.out.print("Edit category: ");
                                                    String category = in.next();
                                                    tutorial.setCategory(category);
                                                    System.out.println(tutorial);
                                                    req = new Request("EDIT_TUTORIAL", tutorial.getId(), tutorial);
                                                    oos.writeObject(req);

                                                    rep = (Reply)ois.readObject();
                                                    System.out.println(rep.getCode());
                                                }
                                            }
                                        }
                                    }
                                    if(choice_3 == 2) {
                                        System.out.println("Category:");
                                        String category = in.next();
                                        in.nextLine();
                                        System.out.println("Title:");
                                        String title = in.nextLine();
                                        System.out.println("Description:");
                                        String description = in.nextLine();
                                        System.out.println("What is needed:");
                                        String needings = in.nextLine();

                                        Tutorial tutorial = new Tutorial(null, category, title, description, needings);

                                        req = new Request("ADD_TUTORIAL", tutorial);
                                        oos.writeObject(req);

                                        rep = (Reply)ois.readObject();
                                        System.out.println(rep.getCode());
                                    }
                                    if (choice_3 == 3) {
                                        req = new Request("VIEW_TUTORIALS");
                                        oos.writeObject(req);

                                        rep  = (Reply)ois.readObject();

                                        ArrayList<Tutorial> tutorials = rep.getTutorials();

                                        for (Tutorial tutorial: tutorials) {
                                            System.out.println(tutorial.getId() + tutorial.getTitle() + "; Rating: " + tutorial.getRating() + "; Category: " + tutorial.getCategory());
                                        }

                                        System.out.println("Which tutorial you want to delete?");
                                        Long tutorNum = in.nextLong();

                                        for (Tutorial tutorial: tutorials){
                                            if(tutorNum.equals(tutorial.getId())){
                                                req = new Request("DELETE_TUTORIAL", tutorial.getId());
                                                oos.writeObject(req);

                                                rep = (Reply)ois.readObject();
                                                System.out.println(rep.getCode());
                                            }
                                        }
                                    }

                                    if(choice_3 == 0) {
                                        break;
                                    }
                                }
                            }
                            else {
                                System.out.println("Choose:\n" +
                                        "1.Tutorials;\n" +
                                        "2.Goods;\n" +
                                        "0. break;\n");

                                int choice_2 = in.nextInt();
                                if (choice_2 == 1) {
                                    req = new Request("VIEW_COMMENTS");
                                    oos.writeObject(req);

                                    rep  = (Reply)ois.readObject();
                                    ArrayList<Comment> comments = rep.getComments();
                                    req = new Request("VIEW_TUTORIALS");
                                    oos.writeObject(req);

                                    rep  = (Reply)ois.readObject();

                                    ArrayList<Tutorial> tutorials = rep.getTutorials();

                                    for (Tutorial tutorial: tutorials) {
                                        System.out.println(tutorial.getId() + tutorial.getTitle() + "; Rating: " + tutorial.getRating() + "; Category: " + tutorial.getCategory());
                                    }

                                    System.out.println("Which tutorial you want to read?");
                                    Long tutorNum = in.nextLong();


                                    for(Tutorial tutorial : tutorials){
                                        if(tutorNum.equals(tutorial.getId())){
                                            System.out.println(tutorial);
                                        }
                                    }

                                    ArrayList<Comment> tutorial_comments = new ArrayList<>();


                                    for(Comment comment : comments) {
                                        if(comment.getContent_id().equals(tutorNum)){
                                            for(User commented_user: users){
                                                if(comment.getUser_id().equals(commented_user.getUser_id())){
                                                    System.out.println(comment.getDate() + " " + commented_user.getUsername() + " wrote" + '\n' + comment.getComment_text());
                                                }
                                            }
                                            tutorial_comments.add(comment);
                                        }
                                    }
                                    assert false;
                                    if (tutorial_comments.size() == 0){
                                        System.out.println("No comments left");
                                    }

                                    System.out.println("Do you want to rate or comment this tutorial?\n" +
                                            "1.Comment;\n" +
                                            "2.Rate;");
                                    int comment_or_rate = in.nextInt();
                                    if(comment_or_rate == 1){
                                        System.out.println("Leave your thoughts:");
                                        in.nextLine();
                                        String comment_text = in.nextLine();

                                        Date date = new Date();
                                        SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                                        String current_date = formatter.format(date);

                                        Comment comment = new Comment(null, tutorNum, user.getUser_id(), current_date, comment_text);

                                        req = new Request("ADD_COMMENT", comment);
                                        oos.writeObject(req);

                                        rep = (Reply)ois.readObject();
                                        System.out.println(rep.getCode());
                                    }
                                    if(comment_or_rate == 2){
                                        System.out.println("Please rate: 1 2 3 4 5");
                                        int rate = in.nextInt();
                                        for(Tutorial tutorial : tutorials) {
                                            if(tutorNum.equals(tutorial.getId())){
                                                int new_rated_user = tutorial.getRatedUser_count() + 1;
                                                tutorial.setRatedUser_count(new_rated_user);
                                                double rating = (tutorial.getRating() + rate) / new_rated_user;
                                                tutorial.setRating(rating);
                                                req = new Request("EDIT_TUTORIAL", tutorial.getId(), tutorial);
                                                oos.writeObject(req);
                                            }
                                        }
                                    }



                                }
                                if (choice_2 == 2) {
                                    break;
                                }
                            }
                        }
                    }
                }
                if (choice == 3) {
                    break;
                }
            }
            oos.close();
            ois.close();
        }catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

         */
    }
}
