package sample;

import java.io.Serializable;
import java.util.ArrayList;

public abstract class Content implements Serializable {
    private Long id;
    private String category;
    private String title;
    private String description;
    private double rating;
    private int ratedUser_count;

    public Content() {
    }

    public Content(Long id, String category, String title, String description) {
        this.id = id;
        this.category = category;
        this.title = title;
        this.description = description;
    }

    public Content(Long id, String category, String title, String description, double rating, int ratedUser_count) {
        this.id = id;
        this.category = category;
        this.title = title;
        this.description = description;
        this.rating = rating;
        this.ratedUser_count = ratedUser_count;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getRating() {
        return rating;
    }

    public void setRating(double rating) {
        this.rating = rating;
    }

    public int getRatedUser_count() {
        return ratedUser_count;
    }

    public void setRatedUser_count(int ratedUser_count) {
        this.ratedUser_count = ratedUser_count;
    }

    @Override
    public String toString() {
        return "Content{" +
                "id=" + id +
                ", category='" + category + '\'' +
                ", title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", rating=" + rating +
                ", ratedUser_count=" + ratedUser_count +
                '}';
    }
}
