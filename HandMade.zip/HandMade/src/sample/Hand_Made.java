package sample;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import org.omg.CORBA.TRANSACTION_MODE;

public class Hand_Made {


    private static ObservableList<String> delete_list = FXCollections.observableArrayList();
    private static ObservableList<String> edit_list = FXCollections.observableArrayList();
    private static ObservableList<String> main_tutorial_list = FXCollections.observableArrayList();
    private static ObservableList<String> main_good_list = FXCollections.observableArrayList();
    private static ObservableList<String> comments_list = FXCollections.observableArrayList();
    private static Tutorial selected_tutorial;
    private static Good selected_good;
    private static Long user_id;
    private static Long content_id;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private AnchorPane sign_in_pane;

    @FXML
    private Text error_text;

    @FXML
    private TextField username_field;

    @FXML
    private TextField password_field;

    @FXML
    private Button register_button;

    @FXML
    private Button sign_button;

    @FXML
    private AnchorPane register_pane;

    @FXML
    private TextField username_reg_field;

    @FXML
    private TextField password_reg_field;

    @FXML
    private TextField pass_conf_reg_field;

    @FXML
    private Button saveUser_button;

    @FXML
    private Label password_error;

    @FXML
    private Label username_error;

    @FXML
    private AnchorPane admin_pane;

    @FXML
    private MenuButton add_menu_button;

    @FXML
    private MenuItem add_tutorial_item;

    @FXML
    private MenuItem add_good_item;

    @FXML
    private MenuButton edit_menu_button;

    @FXML
    private MenuItem edit_tutorial_item;

    @FXML
    private MenuItem edit_good_item;

    @FXML
    private MenuButton delete_menu_button;

    @FXML
    private MenuItem delete_tutorial_item;

    @FXML
    private MenuItem delete_good_item;

    @FXML
    private Button income_button;

    @FXML
    private AnchorPane add_tutorial_pane;

    @FXML
    private MenuButton add_category_menu;

    @FXML
    private TextField add_tutorial_title;

    @FXML
    private TextArea add_tutorial_desc;

    @FXML
    private TextArea add_tutorial_need;

    @FXML
    private Button add_button;

    @FXML
    private AnchorPane add_good_pane;

    @FXML
    private MenuButton add_good_category_menu;

    @FXML
    private TextField add_good_title;

    @FXML
    private TextArea add_good_desc;

    @FXML
    private Button add_good_button;

    @FXML
    private MenuButton add_good_material_menu;

    @FXML
    private TextField add_good_colour;

    @FXML
    private TextField add_good_price;

    @FXML
    private TextField add_good_count;

    @FXML
    private AnchorPane delete_pane;

    @FXML
    private ListView<String> delete_listview;

    @FXML
    private Button delete_button;

    @FXML
    private AnchorPane edit_pane;

    @FXML
    private ListView<String> edit_listview;

    @FXML
    private Button edit_list_button;

    @FXML
    private AnchorPane edit_tutorial_pane;

    @FXML
    private MenuButton edit_category_menu;

    @FXML
    private TextField edit_tutorial_title;

    @FXML
    private TextArea edit_tutorial_desc;

    @FXML
    private TextArea edit_tutorial_need;

    @FXML
    private Button edit_tutorial_button;

    @FXML
    private AnchorPane edit_good_pane;

    @FXML
    private MenuButton edit_good_category_menu;

    @FXML
    private TextField edit_good_title;

    @FXML
    private TextArea edit_good_desc;

    @FXML
    private MenuButton edit_good_material_menu;

    @FXML
    private TextField edit_good_colour;

    @FXML
    private TextField edit_good_price;

    @FXML
    private TextField edit_good_count;

    @FXML
    private Button edit_good_button;

    @FXML
    private AnchorPane user_pane;

    @FXML
    private Button all_tutorials_button;

    @FXML
    private Button all_goods_button;

    @FXML
    private Button user_profile_page;

    @FXML
    private TextField search_field;

    @FXML
    private Button search_button;

    @FXML
    private AnchorPane search_pane;

    @FXML
    private ListView<String> find_tutorial_listview;

    @FXML
    private ListView<String> find_good_listview;

    @FXML
    private Button details_button;

    @FXML
    private AnchorPane tutorial_details_pane;

    @FXML
    private Text tutorial_title;

    @FXML
    private Text tutorial_desc;

    @FXML
    private Text tutorial_need;

    @FXML
    private Button follow_button;

    @FXML
    private ListView<String> comments_listview;

    @FXML
    private TextArea commenting_field;

    @FXML
    private Button comment_button;

    @FXML
    private Button unfollow_button;

    @FXML
    void initialize() {
        register_pane.setVisible(false);
        admin_pane.setVisible(false);
        add_tutorial_pane.setVisible(false);
        add_good_pane.setVisible(false);
        delete_pane.setVisible(false);
        edit_pane.setVisible(false);
        error_text.setVisible(false);
        password_error.setVisible(false);
        username_error.setVisible(false);
        edit_tutorial_pane.setVisible(false);
        edit_good_pane.setVisible(false);
        user_pane.setVisible(false);
        search_pane.setVisible(false);
        tutorial_details_pane.setVisible(false);
        unfollow_button.setVisible(false);
        follow_button.setVisible(false);


        sign_button.setOnAction(event ->  {
            try {
                String username = username_field.getText();
                String password = password_field.getText();

                Request req = new Request("VIEW_USERS");
                Main.oos.writeObject(req);

                Reply rep = (Reply)Main.ois.readObject();
                ArrayList<User> users = rep.getUsers();

                boolean exists = false;
                for(User user : users) {
                    if(user.getUsername().equals(username) && user.getPassword().equals(password)) {
                        exists = true;
                        error_text.setVisible(false);
                        req = new Request("SET_AUTHENTICATED_USER", user.getUser_id());
                        Main.oos.writeObject(req);
                        if (user.isAdmin()){
                            admin_pane.setVisible(true);
                        }
                        else {
                            user_id = user.getUser_id();
                            user_pane.setVisible(true);
                            search_pane.setVisible(true);
                            req = new Request("VIEW_TUTORIALS");
                            Main.oos.writeObject(req);

                            rep  = (Reply)Main.ois.readObject();
                            ArrayList<Tutorial> tutorials = rep.getTutorials();

                            req = new Request("VIEW_GOODS");
                            Main.oos.writeObject(req);

                            rep  = (Reply)Main.ois.readObject();
                            ArrayList<Good> goods = rep.getGoods();

                            main_tutorial_list.clear();
                            for(Tutorial tutorial : tutorials) {
                                main_tutorial_list.add(tutorial.details());
                            }
                            find_tutorial_listview.setItems(main_tutorial_list);

                            main_good_list.clear();
                            for(Good good : goods) {
                                main_good_list.add(good.details());
                            }
                            find_good_listview.setItems(main_good_list);

                        }
                    }

                    /* IT BECOMES AUTHENTICATED BUT THE TEXT APPEARS ANYWAY ((((( */

                    else {
                        exists = false;
                    }
                }
                 if(!exists) {
                     error_text.setVisible(true);
                 }
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        register_button.setOnAction(event -> {
            sign_in_pane.setVisible(false);
            admin_pane.setVisible(false);
            add_tutorial_pane.setVisible(false);
            add_good_pane.setVisible(false);
            register_pane.setVisible(true);
            saveUser_button.setOnAction(event1 -> {
                try {
                    boolean error_check = false;
                    String username = username_reg_field.getText();
                    String password = password_reg_field.getText();
                    String conf_password = pass_conf_reg_field.getText();

                    Request req = new Request("VIEW_USERS");
                    Main.oos.writeObject(req);

                    Reply rep = (Reply)Main.ois.readObject();
                    ArrayList<User> users = rep.getUsers();

                    for(User user: users) {
                        if(user.getUsername().equals(username)){
                            password_error.setVisible(false);
                            username_error.setVisible(true);
                            error_check = true;
                        }
                        else if (!conf_password.equals(password)) {
                            username_error.setVisible(false);
                            password_error.setVisible(true);
                            error_check = true;
                        }
                        else {
                            error_check = false;
                        }
                    }

                    if(!error_check){
                        User new_user = new User(null, username, password, false, false);
                        req = new Request("ADD_USER", new_user);
                        Main.oos.writeObject(req);

                        rep = (Reply)Main.ois.readObject();
                        System.out.println(rep.getCode());

                        register_pane.setVisible(false);
                        sign_in_pane.setVisible(true);
                    }
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
            });
        });

        add_tutorial_item.setOnAction(event -> {
            delete_menu_button.setText("DELETE");
            edit_menu_button.setText("EDIT");
            add_menu_button.setText(add_tutorial_item.getText());
            add_good_pane.setVisible(false);
            delete_pane.setVisible(false);
            edit_pane.setVisible(false);
            add_tutorial_pane.setVisible(true);
            ObservableList<MenuItem> category_items = add_category_menu.getItems();

            for (MenuItem selected_item : category_items) {
                EventHandler<ActionEvent> event1 = event2 -> add_category_menu.setText(((MenuItem) event2.getSource()).getText());
                selected_item.setOnAction(event1);
            }
        });

        add_button.setOnAction(event -> {
            if(add_tutorial_pane.isVisible() && !add_category_menu.getText().equals("Category")) {
                String category = add_category_menu.getText();
                String title = add_tutorial_title.getText();
                String description = add_tutorial_desc.getText();
                String needings = add_tutorial_need.getText();

                Tutorial tutorial = new Tutorial(null, category, title, description, needings);

                try {
                    Request req = new Request("ADD_TUTORIAL", tutorial);
                    Main.oos.writeObject(req);

                    Reply rep = (Reply) Main.ois.readObject();
                    System.out.println(rep.getCode());
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
                add_category_menu.setText("Category");
                add_tutorial_title.setText("");
                add_tutorial_desc.setText("");
                add_tutorial_need.setText("");
            }
        });

        add_good_item.setOnAction(event -> {
            delete_menu_button.setText("DELETE");
            edit_menu_button.setText("EDIT");
            add_menu_button.setText(add_good_item.getText());
            add_tutorial_pane.setVisible(false);
            delete_pane.setVisible(false);
            edit_pane.setVisible(false);
            add_good_pane.setVisible(true);

            ObservableList<MenuItem> category_items = add_good_category_menu.getItems();
            ObservableList<MenuItem> material_items = add_good_material_menu.getItems();

            for (MenuItem selected_item : category_items) {
                EventHandler<ActionEvent> event1 = event2 -> add_good_category_menu.setText(((MenuItem) event2.getSource()).getText());
                selected_item.setOnAction(event1);
            }

            for (MenuItem selected_item : material_items) {
                EventHandler<ActionEvent> event1 = event2 -> add_good_material_menu.setText(((MenuItem) event2.getSource()).getText());
                selected_item.setOnAction(event1);
            }
        });

        add_good_button.setOnAction(event -> {
            if(add_good_pane.isVisible() && !add_good_category_menu.getText().equals("Category")) {
                String category = add_good_category_menu.getText();
                String title = add_good_title.getText();
                String description = add_good_desc.getText();
                String material = add_good_material_menu.getText();
                String colour = add_good_colour.getText();
                int price = Integer.parseInt(add_good_price.getText());
                int count = Integer.parseInt(add_good_count.getText());

                Good good = new Good(null, category, title, description, material, colour, price, count);
                System.out.println(good);

                try {
                    Request req = new Request("ADD_GOOD", good);
                    Main.oos.writeObject(req);

                    Reply rep = (Reply) Main.ois.readObject();
                    System.out.println(rep.getCode());
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }
                add_good_category_menu.setText("Category");
                add_good_title.setText("");
                add_good_desc.setText("");
                add_good_material_menu.setText("Material");
                add_good_colour.setText("");
                add_good_price.setText("");
                add_good_count.setText("");
            }
        });

        delete_tutorial_item.setOnAction(event -> {
            add_menu_button.setText("ADD");
            edit_menu_button.setText("EDIT");
            delete_menu_button.setText(delete_tutorial_item.getText());
            add_good_pane.setVisible(false);
            add_tutorial_pane.setVisible(false);
            edit_pane.setVisible(false);
            delete_pane.setVisible(true);

            try {
                Request req = new Request("VIEW_TUTORIALS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Tutorial> tutorials = rep.getTutorials();

                delete_list.clear();
                for(Tutorial tutorial : tutorials) {
                    delete_list.add(tutorial.details());
                }
                delete_listview.setItems(delete_list);

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        delete_good_item.setOnAction(event -> {
            add_menu_button.setText("ADD");
            edit_menu_button.setText("EDIT");
            delete_menu_button.setText(delete_good_item.getText());
            add_good_pane.setVisible(false);
            add_tutorial_pane.setVisible(false);
            edit_pane.setVisible(false);
            delete_pane.setVisible(true);

            try {
                Request req = new Request("VIEW_GOODS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Good> goods = rep.getGoods();

                delete_list.clear();
                for(Good good : goods) {
                    delete_list.add(good.details());
                }
                delete_listview.setItems(delete_list);

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        delete_button.setOnAction(event -> {
            try {
                Request req = new Request("VIEW_TUTORIALS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Tutorial> tutorials = rep.getTutorials();

                req = new Request("VIEW_GOODS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();
                ArrayList<Good> goods = rep.getGoods();


                String selected = delete_listview.getSelectionModel().getSelectedItem();

                for(int i = 0; i < delete_list.size(); i++) {
                    if(delete_list.get(i).equals(selected)){
                        delete_list.remove(i);
                    }
                }

                for(Tutorial tutorial : tutorials) {
                    if(selected.contains(tutorial.getTitle())){
                        req = new Request("DELETE_TUTORIAL", tutorial.getId());
                        Main.oos.writeObject(req);

                        rep = (Reply)Main.ois.readObject();
                        System.out.println(rep.getCode());
                    }
                }

                for(Good good : goods) {
                    if(selected.contains(good.getTitle())){
                        req = new Request("DELETE_GOOD", good.getId());
                        Main.oos.writeObject(req);

                        rep = (Reply)Main.ois.readObject();
                        System.out.println(rep.getCode());
                    }
                }


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        edit_tutorial_item.setOnAction(event -> {
            edit_pane.setVisible(true);
            add_menu_button.setText("ADD");
            delete_menu_button.setText("DELETE");
            add_tutorial_pane.setVisible(false);
            add_good_pane.setVisible(false);
            delete_pane.setVisible(false);
            edit_good_pane.setVisible(false);
            edit_tutorial_pane.setVisible(false);
            edit_menu_button.setText(edit_tutorial_item.getText());
            try {
                Request req = new Request("VIEW_TUTORIALS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Tutorial> tutorials = rep.getTutorials();

                edit_list.clear();
                for(Tutorial tutorial : tutorials) {
                    edit_list.add(tutorial.details());
                }
                edit_listview.setItems(edit_list);
            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        edit_good_item.setOnAction(event -> {
            edit_pane.setVisible(true);
            add_menu_button.setText("ADD");
            delete_menu_button.setText("DELETE");
            add_tutorial_pane.setVisible(false);
            add_good_pane.setVisible(false);
            delete_pane.setVisible(false);
            edit_good_pane.setVisible(false);
            edit_tutorial_pane.setVisible(false);
            edit_menu_button.setText(edit_good_item.getText());
            try {
                Request req = new Request("VIEW_GOODS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Good> goods = rep.getGoods();

                edit_list.clear();
                for(Good good : goods) {
                    edit_list.add(good.details());
                }
                edit_listview.setItems(edit_list);

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        edit_list_button.setOnAction(event -> {
            edit_listview.setVisible(false);
            edit_list_button.setVisible(false);
            try {

                Request req = new Request("VIEW_TUTORIALS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Tutorial> tutorials = rep.getTutorials();

                req = new Request("VIEW_GOODS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();
                ArrayList<Good> goods = rep.getGoods();


                String selected = edit_listview.getSelectionModel().getSelectedItem();

                for(Tutorial tutorial : tutorials) {
                    if (selected.contains(tutorial.getTitle())) {
                        selected_tutorial = tutorial;
                        edit_tutorial_pane.setVisible(true);
                        edit_category_menu.setText(tutorial.getCategory());
                        edit_tutorial_title.setText(tutorial.getTitle());
                        edit_tutorial_desc.setText(tutorial.getDescription());
                        edit_tutorial_need.setText(tutorial.getNeedings());

                        ObservableList<MenuItem> category_items = edit_category_menu.getItems();

                        for (MenuItem selected_item : category_items) {
                            EventHandler<ActionEvent> event1 = event2 -> edit_category_menu.setText(((MenuItem) event2.getSource()).getText());
                            selected_item.setOnAction(event1);
                        }


                    }

                }

                for(Good good : goods) {
                    if(selected.contains(good.getTitle())){
                        selected_good = good;
                        edit_good_pane.setVisible(true);
                        edit_good_category_menu.setText(good.getCategory());
                        edit_good_title.setText(good.getTitle());
                        edit_good_desc.setText(good.getDescription());
                        edit_good_material_menu.setText(good.getMaterial());
                        edit_good_colour.setText(good.getColour());
                        edit_good_price.setText(Double.toString(good.getPrice()));
                        edit_good_count.setText(Integer.toString(good.getCount()));

                        ObservableList<MenuItem> category_items = edit_good_category_menu.getItems();
                        ObservableList<MenuItem> material_items = edit_good_material_menu.getItems();

                        for (MenuItem selected_item : category_items) {
                            EventHandler<ActionEvent> event1 = event2 -> edit_good_category_menu.setText(((MenuItem) event2.getSource()).getText());
                            selected_item.setOnAction(event1);
                        }

                        for (MenuItem selected_item : material_items) {
                            EventHandler<ActionEvent> event1 = event2 -> edit_good_material_menu.setText(((MenuItem) event2.getSource()).getText());
                            selected_item.setOnAction(event1);
                        }
                    }
                }


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        edit_tutorial_button.setOnAction(event_1 -> {
            try {

                String category = edit_category_menu.getText();
                String title = edit_tutorial_title.getText();
                String description = edit_tutorial_desc.getText();
                String needings = edit_tutorial_need.getText();

                selected_tutorial.setCategory(category);
                selected_tutorial.setTitle(title);
                selected_tutorial.setDescription(description);
                selected_tutorial.setNeedings(needings);

                Request req = new Request("EDIT_TUTORIAL", selected_tutorial.getId(), selected_tutorial);
                Main.oos.writeObject(req);

                Reply rep = (Reply)Main.ois.readObject();
                System.out.println(rep.getCode());

                edit_tutorial_pane.setVisible(false);

                try {
                    req = new Request("VIEW_TUTORIALS");
                    Main.oos.writeObject(req);

                    rep  = (Reply)Main.ois.readObject();
                    ArrayList<Tutorial> tutorials = rep.getTutorials();

                    edit_list.clear();
                    for(Tutorial tutorial : tutorials) {
                        edit_list.add(tutorial.details());
                    }
                    edit_listview.setItems(edit_list);
                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }

                edit_listview.setVisible(true);
                edit_list_button.setVisible(true);


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        edit_good_button.setOnAction(event_1 -> {
            try {
                String category = edit_good_category_menu.getText();
                String title = edit_good_title.getText();
                String description = edit_good_desc.getText();
                String material = edit_good_material_menu.getText();
                String colour = edit_good_colour.getText();
                double price = Double.parseDouble(edit_good_price.getText());
                int count = Integer.parseInt(edit_good_count.getText());


                selected_good.setCategory(category);
                selected_good.setTitle(title);
                selected_good.setDescription(description);
                selected_good.setMaterial(material);
                selected_good.setColour(colour);
                selected_good.setPrice(price);
                selected_good.setCount(count);

                Request req = new Request("EDIT_GOOD", selected_good.getId(), selected_good);
                Main.oos.writeObject(req);

                Reply rep = (Reply)Main.ois.readObject();
                System.out.println(rep.getCode());

                edit_good_pane.setVisible(false);
                edit_listview.setVisible(true);
                edit_list_button.setVisible(true);


                try {
                    req = new Request("VIEW_GOODS");
                    Main.oos.writeObject(req);

                    rep  = (Reply)Main.ois.readObject();
                    ArrayList<Good> goods = rep.getGoods();

                    edit_list.clear();
                    for(Good good : goods) {
                        edit_list.add(good.details());
                    }
                    edit_listview.setItems(edit_list);

                } catch (IOException | ClassNotFoundException e) {
                    e.printStackTrace();
                }


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        search_button.setOnAction(event -> {
            String to_find = search_field.getText();
            try {
                Request req = new Request("VIEW_TUTORIALS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Tutorial> tutorials = rep.getTutorials();

                req = new Request("VIEW_GOODS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();
                ArrayList<Good> goods = rep.getGoods();

                main_tutorial_list.clear();
                for(Tutorial tutorial : tutorials) {
                    if(tutorial.getCategory().contains(to_find) || tutorial.getTitle().contains(to_find) || tutorial.getDescription().contains(to_find) || tutorial.getNeedings().contains(to_find)) {
                        main_tutorial_list.add(tutorial.details());
                    }
                }
                find_tutorial_listview.setItems(main_tutorial_list);



                main_good_list.clear();
                for(Good good : goods) {
                    if(good.getTitle().contains(to_find) || good.getCategory().contains(to_find) || good.getDescription().contains(to_find) || good.getMaterial().contains(to_find) || good.getColour().contains(to_find)){
                        main_good_list.add(good.details());
                    }
                }
                find_good_listview.setItems(main_good_list);

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }

        });

        details_button.setOnAction(event -> {

            try {
                Request req = new Request("VIEW_TUTORIALS");
                Main.oos.writeObject(req);

                Reply rep  = (Reply)Main.ois.readObject();
                ArrayList<Tutorial> tutorials = rep.getTutorials();

                req = new Request("VIEW_GOODS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();
                ArrayList<Good> goods = rep.getGoods();

                req = new Request("VIEW_COMMENTS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();
                ArrayList<Comment> comments = rep.getComments();


                req = new Request("VIEW_USERS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();

                ArrayList<User> users = rep.getUsers();

                String selected_tutorial = find_tutorial_listview.getSelectionModel().getSelectedItem();

                String selected_good = find_good_listview.getSelectionModel().getSelectedItem();

                for(Tutorial tutorial : tutorials) {
                    if(selected_tutorial.contains(tutorial.getTitle())){
                        content_id = tutorial.getId();
                        tutorial_details_pane.setVisible(true);
                        search_pane.setVisible(false);
                        tutorial_title.setText(tutorial.getTitle());
                        tutorial_desc.setText(tutorial.getDescription());
                        tutorial_need.setText(tutorial.getNeedings());

                        comments_list.clear();
                        for(Comment comment : comments) {
                            if(comment.getContent_id().equals(tutorial.getId())){
                                for(User commented_user: users){
                                    if(comment.getUser_id().equals(commented_user.getUser_id())){
                                        comments_list.add(comment.getDate() + " " + commented_user.getUsername() + " wrote" + '\n' + comment.getComment_text());
                                    }
                                }
                            }
                        }

                        comments_listview.setItems(comments_list);

                        req = new Request("GET_ALL_FOLLOWERS", content_id);
                        Main.oos.writeObject(req);
                        rep  = (Reply)Main.ois.readObject();
                        ArrayList<Follower> followers = rep.getFollowers();

                        for(Follower follower : followers) {
                            System.out.println(follower);
                        }

                        for(Follower follower : followers) {
                            if(follower.getUser_id().equals(user_id)) {
                                unfollow_button.setVisible(true);
                            }
                            else {
                                follow_button.setVisible(true);
                            }
                        }

                    }
                }

                /*for(Good good : goods) {
                    if(selected_good.contains(good.getTitle())){
                    }
                }*/


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        comment_button.setOnAction(event1 -> {
            try {
                String comment_text = commenting_field.getText();

                Date date = new Date();
                SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                String current_date = formatter.format(date);

                Comment comment = new Comment(null, content_id, user_id, current_date, comment_text);

                Request req = new Request("ADD_COMMENT", comment);
                Main.oos.writeObject(req);

                Reply rep = (Reply)Main.ois.readObject();
                System.out.println(rep.getCode());

                req = new Request("VIEW_COMMENTS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();
                ArrayList<Comment> comments = rep.getComments();

                req = new Request("VIEW_USERS");
                Main.oos.writeObject(req);

                rep  = (Reply)Main.ois.readObject();

                ArrayList<User> users = rep.getUsers();

                comments_list.clear();
                for(Comment one_comment : comments) {
                    if(one_comment.getContent_id().equals(content_id)){
                        for(User commented_user: users){
                            if(one_comment.getUser_id().equals(commented_user.getUser_id())){
                                comments_list.add(one_comment.getDate() + " " + commented_user.getUsername() + " wrote" + '\n' + one_comment.getComment_text());
                            }
                        }
                    }
                }

                comments_listview.setItems(comments_list);

                commenting_field.setText("");

            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        follow_button.setOnAction(event -> {
            try {
                Follower follower = new Follower(content_id, user_id);

                Request req = new Request("SET_USER_FOLLOWER", follower);
                Main.oos.writeObject(req);

                Reply rep = (Reply)Main.ois.readObject();
                System.out.println(rep.getCode());
                unfollow_button.setVisible(true);
                follow_button.setVisible(false);


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });

        unfollow_button.setOnAction(event -> {
            try {
                Request req = new Request("UNFOLLOW_USER", content_id);
                Main.oos.writeObject(req);

                Reply rep = (Reply)Main.ois.readObject();
                System.out.println(rep.getCode());
                follow_button.setVisible(true);
                unfollow_button.setVisible(false);


            } catch (IOException | ClassNotFoundException e) {
                e.printStackTrace();
            }
        });


    }
}
