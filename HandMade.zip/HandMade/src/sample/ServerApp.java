package sample;

import java.io.IOException;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ServerApp implements Serializable {

    private Connection conn = null;
    private ServerSocket ss = null;

    public ServerApp(){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/hand_made?useUnicode=true&serverTimezone=UTC", "root", "");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            ss = new ServerSocket(1999);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void start(){
        while(true){
            try {
                System.out.println("waiting for a client...");

                Socket socket = ss.accept();
                System.out.println("client connected " + socket.getInetAddress().getHostAddress());
                ClientHandler ch = new ClientHandler(socket, conn);
                ch.start();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    public static void main(String[] args){
        ServerApp sa = new ServerApp();
        sa.start();
    }
}
