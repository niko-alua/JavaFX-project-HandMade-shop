package sample;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class Main extends Application{
    static ObjectOutputStream oos;
    static ObjectInputStream ois;
    @Override
    public void start(Stage primaryStage) throws Exception{
        try {
            Socket socket = new Socket("127.0.0.1", 1999);
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());
            Parent root = FXMLLoader.load(getClass().getResource("hand_made.fxml"));
            primaryStage.setTitle("Hand Made");
            primaryStage.setScene(new Scene(root));
            primaryStage.show();
            primaryStage.setOnCloseRequest(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent windowEvent) {
                    Request req = new Request("BYE");
                    try {
                        oos.writeObject(req);
                        oos.close();
                        ois.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

    /*public static void main(String[] args) {
        try{
            Socket socket = new Socket("127.0.0.1", 1999);
            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());
            ObjectInputStream ois = new ObjectInputStream(socket.getInputStream());
            Scanner in = new Scanner(System.in);
            while (true){
                System.out.println("Choose:\n" +
                        "1. to register;\n" +
                        "2. to login;\n" +
                        "0. break;\n");
                int choice = in.nextInt();
                if(choice == 1){
                    System.out.println("Please enter");
                    System.out.print("Username: ");
                    String username = in.next();
                    System.out.print("\nPassword: ");
                    String password = in.next();
                    System.out.print("\nConfirm the password: ");
                    String passwordCheck = in.next();
                    if(!passwordCheck.equals(password)){
                        System.out.println("\nPasswords do not match");
                    }
                    else {
                        User user = new User(null, username, password, true, false);
                        Request req =new Request("ADD_USER", user);
                    }
                }
            }
        }  catch (
                IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /*private static User admin = new User("admin", "admin", false, true);
    private static ArrayList<Good> goods = new ArrayList<>();
    private static ArrayList<Tutorial> tutorials = new ArrayList<>();
    private static ArrayList<Comment> comments = new ArrayList<>();
    private static ArrayList<User> users = new ArrayList<>();

    private static void registration() {
        Scanner scn = new Scanner(System.in);
        System.out.println("Please enter");
        System.out.print("Username: ");
        String username = scn.next();
        System.out.print("\nPassword: ");
        String password = scn.next();
        System.out.print("\nConfirm the password: ");
        String passwordCheck = scn.next();
        if(!passwordCheck.equals(password)){
            System.out.println("\nPasswords do not match");
            registration();
        }
        else {
            users.add(new User(username, password, true, false));
            userHomePage();
        }
    }

    private static void login() {
        Scanner scn = new Scanner(System.in);
        System.out.println("Please enter");
        System.out.print("Username: ");
        String username = scn.next();
        System.out.println("\nPassword: ");
        String password = scn.next();
        start(username, password);
    }

    private static void start(String un, String pass){
        if(un.equals(admin.getUsername()) && pass.equals(admin.getPassword())){
            adminStart();
        }
        else{
            userHomePage();
        }
    }

    private static void adminStart() {
    }

    private static void userHomePage() {
        Scanner scn = new Scanner(System.in);
        System.out.println("Choose:\n" +
                "1.Tutorials;\n" +
                "2.Goods;\n" +
                "0. break;\n");
        int choice = scn.nextInt();
        switch (choice) {
            case 1:
                tutorialsPage();
                break;
            case 2:
                goodsPage();
                break;
            case 0:
                break;
        }
    }

    private static void tutorialsPage() {
        int j = 0;
        Scanner scn = new Scanner(System.in);
        for (int i = 0; i < tutorials.size(); i++){
            //System.out.println((i + 1) + ". " + tutorials.get(i).showDetails());
        }
        System.out.println("Which tutorial you want to read?");
        int tutorNum = scn.nextInt();
        for (int i = 0; i < tutorials.size(); i++){
            if(tutorNum == (i + 1)){
                //System.out.println(tutorials.get(i).showFullDetails());
                if(tutorials.get(i).getTitle().equals(comments.get(j).getContent())){
                    System.out.println(comments.get(j).showComment());
                }
            }
        }
        System.out.println("1.write comment;\n" +
                "0. break;\n");
        int choice = scn.nextInt();
        switch (choice) {
            case 1:

                break;
            case 0:
                break;
        }
    }

    private static void goodsPage() {
    }

    public static void main(String[] args) {
        Scanner scn = new Scanner(System.in);
        System.out.println("Choose:\n" +
                "1. to register;\n" +
                "2. to login;\n" +
                "0. break;\n");
        int choice = scn.nextInt();
        switch (choice) {
            case 1:

                registration();
                break;
            case 2:
                login();
                break;
            case 0:
                break;
        }
    }
     */
}