package sample;

public class Follower {
    private Long tutorial_id;
    private Long user_id;

    public Follower() {
    }

    public Follower(Long tutorial_id, Long user_id) {
        this.tutorial_id = tutorial_id;
        this.user_id = user_id;
    }

    public Long getTutorial_id() {
        return tutorial_id;
    }

    public void setTutorial_id(Long tutorial_id) {
        this.tutorial_id = tutorial_id;
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    @Override
    public String toString() {
        return "Follower{" +
                "tutorial_id=" + tutorial_id +
                ", user_id=" + user_id +
                '}';
    }
}
