package sample;

import java.io.Serializable;
import java.util.Date;

public class Comment implements Serializable {
    private Long comment_id;
    private Long content_id;
    private Long user_id;
    private String date;
    private String comment_text;

    public Comment() {
    }

    public Comment(Long comment_id, Long content_id, Long user_id, String date, String comment_text) {
        this.comment_id = comment_id;
        this.content_id = content_id;
        this.user_id = user_id;
        this.date = date;
        this.comment_text = comment_text;
    }

    public Long getComment_id() {
        return comment_id;
    }

    public void setComment_id(Long comment_id) {
        this.comment_id = comment_id;
    }

    public Long getContent_id() {
        return content_id;
    }

    public void setContent_id(Long content_id) {
        this.content_id = content_id;
    }

    public Long getUser_id() {
        return user_id;
    }

    public void setUser_id(Long user_id) {
        this.user_id = user_id;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getComment_text() {
        return comment_text;
    }

    public void setComment_text(String comment_text) {
        this.comment_text = comment_text;
    }

    @Override
    public String toString() {
        return "Comment{" +
                "comment_id=" + comment_id +
                ", content_id=" + content_id +
                ", user_id=" + user_id +
                ", date=" + date +
                ", comment_text='" + comment_text + '\'' +
                '}';
    }
}
