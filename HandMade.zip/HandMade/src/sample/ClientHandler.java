package sample;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientHandler extends Thread {
    private Socket socket;
    private ObjectOutputStream oos = null;
    private ObjectInputStream ois = null;
    private Connection conn;

    public ClientHandler(Socket socket, Connection conn) {
        this.socket = socket;
        this.conn = conn;

        try {
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    public ArrayList<User> getAllUsers() {
        ArrayList<User> users = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from users");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Long user_id = rs.getLong("user_id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                boolean isAuthenticated = rs.getBoolean("isAuthenticated");
                boolean isAdmin = rs.getBoolean("isAdmin");

                users.add(new User(user_id, username, password, isAuthenticated, isAdmin));
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return users;
    }

    public void addUser(User user){
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO users (user_id, username, password, isAuthenticated, isAdmin) VALUES(NULL, ?, ?, ?, ?)");
            ps.setString(1, user.getUsername());
            ps.setString(2, user.getPassword());
            ps.setBoolean(3, user.isAuthenticated());
            ps.setBoolean(4, user.isAdmin());

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void setUserAuthenticated(Long user_id){
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE users SET isAuthenticated = 1 WHERE users.user_id = ?");
            ps.setLong(1, user_id);
            ps.executeUpdate();
            ps.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }


    public ArrayList<Comment> getAllComments() {
        ArrayList<Comment> comments = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from comments");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Long comment_id = rs.getLong("comment_id");
                Long content_id = rs.getLong("content_id");
                Long user_id = rs.getLong("user_id");
                String date = rs.getString("date");
                String comment_text = rs.getString("comment_text");

                comments.add(new Comment(comment_id, content_id, user_id, date, comment_text));
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return comments;
    }

    public void addComment(Comment comment){
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO comments (comment_id, content_id, user_id, date, comment_text) VALUES(NULL, ?, ?, ?, ?)");
            ps.setLong(1, comment.getContent_id());
            ps.setLong(2, comment.getUser_id());
            ps.setString(3, comment.getDate());
            ps.setString(4, comment.getComment_text());

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }


    public ArrayList<Tutorial> getAllTutorials() {
        ArrayList<Tutorial> tutorials = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from tutorials");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Long id = rs.getLong("id");
                String category = rs.getString("category");
                String title = rs.getString("title");
                String description = rs.getString("description");
                double rating = rs.getDouble("rating");
                int ratedUser_count = rs.getInt("ratedUser_count");
                String needings = rs.getString("needings");

                tutorials.add(new Tutorial(id, category, title, description, rating, ratedUser_count, needings));
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return tutorials;
    }

    public void addTutorial(Tutorial tutorial){
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO tutorials (id, category, title, description, rating, ratedUser_count, needings) VALUES(NULL, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, tutorial.getCategory());
            ps.setString(2, tutorial.getTitle());
            ps.setString(3, tutorial.getDescription());
            ps.setDouble(4, tutorial.getRating());
            ps.setInt(5, tutorial.getRatedUser_count());
            ps.setString(6, tutorial.getNeedings());

            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void removeTutorial(Long id){
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM tutorials where id = ?");
            ps.setLong(1, id);
            ps.executeUpdate();
            ps.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void editTutorial(Long id, Tutorial tutorial) {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE tutorials SET category = ?, title = ?, description = ?, rating = ?, ratedUser_count = ?, needings = ? WHERE tutorials.id = ?");
            ps.setString(1, tutorial.getCategory());
            ps.setString(2, tutorial.getTitle());
            ps.setString(3, tutorial.getDescription());
            ps.setDouble(4, tutorial.getRating());
            ps.setInt(5, tutorial.getRatedUser_count());
            ps.setString(6, tutorial.getNeedings());
            ps.setLong(7, id);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void setUserFollowed(Follower follower) {
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO followers (tutorial_id, user_id) VALUES(?, ?)");
            ps.setLong(1, follower.getTutorial_id());
            ps.setLong(2, follower.getUser_id());
            ps.executeUpdate();
            ps.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void unfollowUser(Long tutorial_id) {
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM followers where tutorial_id = ?");
            ps.setLong(1, tutorial_id);
            ps.executeUpdate();
            ps.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    public ArrayList<Follower> getAllFollowers(Long tutorial_id) {
        ArrayList<Follower> followed_users = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from followers WHERE followers.tutorial_id = ?");
            ps.setLong(1, tutorial_id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Long user_id = rs.getLong("user_id");
                followed_users.add(new Follower(tutorial_id, user_id));
            }
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return followed_users;
    }


    public ArrayList<Good> getAllGoods() {
        ArrayList<Good> goods = new ArrayList<>();

        try {
            PreparedStatement ps = conn.prepareStatement("SELECT * from goods");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {

                Long id = rs.getLong("id");
                String category = rs.getString("category");
                String title = rs.getString("title");
                String description = rs.getString("description");
                double rating = rs.getDouble("rating");
                int ratedUser_count = rs.getInt("ratedUser_count");
                String material = rs.getString("material");
                String colour = rs.getString("colour");
                double price = rs.getDouble("price");
                int count = rs.getInt("count");
                int sold = rs.getInt("sold");

                goods.add(new Good(id, category, title, description, rating, ratedUser_count, material, colour, price, count, sold));
            }
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return goods;
    }

    public void addGood(Good good){
        try {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO goods (id, category, title, description, rating, ratedUser_count, material, colour, price, count, sold) VALUES(NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            ps.setString(1, good.getCategory());
            ps.setString(2, good.getTitle());
            ps.setString(3, good.getDescription());
            ps.setDouble(4, good.getRating());
            ps.setInt(5, good.getRatedUser_count());
            ps.setString(6, good.getMaterial());
            ps.setString(7, good.getColour());
            ps.setDouble(8, good.getPrice());
            ps.setInt(9, good.getCount());
            ps.setInt(10, good.getSold());
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void removeGood(Long id){
        try {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM goods where id = ?");
            ps.setLong(1, id);
            ps.executeUpdate();
            ps.close();
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }

    public void editGood(Long id, Good good) {
        try {
            PreparedStatement ps = conn.prepareStatement("UPDATE goods SET category = ?, title = ?, description = ?, rating = ?, ratedUser_count = ?, material = ?, colour = ?, price = ?, count = ?, sold = ? WHERE goods.id = ?");
            ps.setString(1, good.getCategory());
            ps.setString(2, good.getTitle());
            ps.setString(3, good.getDescription());
            ps.setDouble(4, good.getRating());
            ps.setInt(5, good.getRatedUser_count());
            ps.setString(6, good.getMaterial());
            ps.setString(7, good.getColour());
            ps.setDouble(8, good.getPrice());
            ps.setInt(9, good.getCount());
            ps.setInt(10, good.getSold());
            ps.setLong(11, id);
            ps.executeUpdate();
            ps.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    public void run(){
        while(true){
            Request req = null;
            try {
                req = (Request)ois.readObject();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (ClassNotFoundException e) {
                e.printStackTrace();
            }

            if(req.getCode().equals("VIEW_USERS")){
                Reply rep = new Reply();
                ArrayList<User> users = getAllUsers();

                for(User user : users){
                    rep.addUser(user);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("ADD_USER")){
                addUser(req.getUser());

                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("SET_AUTHENTICATED_USER")){
                setUserAuthenticated(req.getId());
            }

            if(req.getCode().equals("VIEW_COMMENTS")){
                Reply rep = new Reply();
                ArrayList<Comment> comments = getAllComments();

                for(Comment comment : comments){
                    rep.addСomment(comment);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("ADD_COMMENT")){
                addComment(req.getComment());

                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("VIEW_TUTORIALS")){
                Reply rep = new Reply();
                ArrayList<Tutorial> tutorials = getAllTutorials();

                for(Tutorial tutorial : tutorials){
                    rep.addTutorial(tutorial);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("ADD_TUTORIAL")){
                addTutorial(req.getTutorial());

                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("DELETE_TUTORIAL")){
                removeTutorial(req.getId());

                Reply rep = new Reply("DELETED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("EDIT_TUTORIAL")) {
                editTutorial(req.getId(), req.getTutorial());

                Reply rep = new Reply("EDITED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("GET_ALL_FOLLOWERS")){

                Reply rep = new Reply();
                ArrayList<Follower> followers = getAllFollowers(req.getId());

                for(Follower follower : followers){
                    rep.addFollower(follower);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

            if(req.getCode().equals("SET_USER_FOLLOWER")) {
                setUserFollowed(req.getFollower());

                Reply rep = new Reply("FOLLOWED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("UNFOLLOW_USER")){
                unfollowUser(req.getId());
                Reply rep = new Reply("UNFOLLOWED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("VIEW_GOODS")){
                Reply rep = new Reply();
                ArrayList<Good> goods = getAllGoods();

                for(Good good : goods){
                    rep.addGood(good);
                }

                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("ADD_GOOD")){
                addGood(req.getGood());

                Reply rep = new Reply("ADDED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("DELETE_GOOD")){
                removeGood(req.getId());

                Reply rep = new Reply("DELETED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("EDIT_GOOD")) {
                editGood(req.getId(), req.getGood());

                Reply rep = new Reply("EDITED SUCCESSFULLY");
                try {
                    oos.writeObject(rep);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if(req.getCode().equals("BYE"))
                break;
        }
    }

}
